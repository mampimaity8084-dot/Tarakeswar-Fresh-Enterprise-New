# Tarakeswar Fresh Fish V7 Master — Repair Audit

তারিখ: 25 Aug 2026

## Repair করা হয়েছে

1. **Customer app JavaScript syntax error fixed**
   - `index.html`-এর boot section-এ literal `\\n` ছিল, যার কারণে browser পুরো script parse করতে পারছিল না।
   - এটি ঠিক করা হয়েছে।

2. **AI Assistant API routing fixed**
   - AI Assistant এখন `TFF_API_BASE` ব্যবহার করবে।
   - Cloudflare frontend + Vercel API deployment-এর জন্য প্রয়োজনীয়।

3. **AI Visual Search API routing fixed**
   - Visual Search-এর hard-coded Netlify URL বাদ দিয়ে configurable API base ব্যবহার করা হয়েছে।

4. **AI Assistant actions fixed**
   - আগে server `open_orders`, `open_wishlist`, `open_cart`, `open_search`, `open_offers`, `open_support` action তৈরি করলেও client শুধু `add_to_cart` দেখত।
   - এখন safe UI actions handle করা হবে।

5. **AI add-to-cart compatibility fixed**
   - বর্তমান customer app-এর `add()` function-এর সঙ্গে AI action compatible করা হয়েছে।

6. **Vercel API compatibility wrappers checked/rebuilt**
   - Existing Netlify-style functions-এর জন্য `/api/*.js` wrappers রাখা হয়েছে।
   - `vercel.json`-এর `/.netlify/functions/* → /api/*` rewrite-এর সঙ্গে compatible।

## Validation

- V6 static check: PASS
- V7 structure check: PASS
- সব JavaScript syntax checks: PASS
- Customer/Admin/Delivery inline JavaScript syntax checks: PASS
- ZIP integrity: PASS

## Supabase status

ZIP-এর code review অনুযায়ী Supabase configuration আছে এবং customer product read-এর জন্য RLS policy migration-ও আছে। তবে live Supabase database-এর বর্তমান rows/RLS runtime response এই environment থেকে সরাসরি verify করা যায়নি। তাই production launch-এর আগে live `fish`, `orders`, `offers` এবং required RPCs একবার test করতে হবে।

## Important deployment architecture

Recommended:

Cloudflare Pages → Customer/Admin/Delivery frontend
Vercel → `/api/*` server functions
Supabase → Database/Auth/Storage/Realtime
Razorpay → Payments
OpenAI → AI Assistant / Visual Search

Cloudflare Pages frontend-এ `native-config.js`-এর `TFF_API_BASE`-এ deployed Vercel API base URL বসাতে হবে।

## Security note

Supabase publishable key browser-এ থাকা স্বাভাবিক; service-role/secret key, Razorpay secret এবং OpenAI secret browser code-এ রাখা যাবে না। এগুলো Vercel environment variables-এ রাখতে হবে।
