
const path = require('path');

function toNetlifyEvent(req) {
  const headers = {};
  for (const [k, v] of Object.entries(req.headers || {})) {
    headers[k.toLowerCase()] = Array.isArray(v) ? v.join(',') : String(v);
  }
  let body = req.body;
  if (body !== undefined && typeof body !== 'string') body = JSON.stringify(body);
  return {
    httpMethod: req.method,
    headers,
    body: body == null ? null : body,
    isBase64Encoded: false,
  };
}

module.exports = function adapt(handler) {
  return async (req, res) => {
    try {
      const event = toNetlifyEvent(req);
      const out = await handler(event, {});
      const status = Number(out?.statusCode) || 200;
      const headers = out?.headers || {};
      for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);
      let body = out?.body ?? '';
      if (out?.isBase64Encoded) {
        res.status(status).send(Buffer.from(body, 'base64'));
      } else {
        res.status(status).send(body);
      }
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal server error' });
    }
  };
};
