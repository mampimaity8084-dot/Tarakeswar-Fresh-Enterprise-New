// Vercel compatibility wrapper for the existing Netlify-style handler.
const mod = require('../netlify/functions/admin-customer.js');
module.exports = async function handler(req, res) {
  const body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body ?? {});
  const event = {
    httpMethod: req.method,
    headers: req.headers || {},
    body,
    queryStringParameters: req.query || {},
    path: req.url || ''
  };
  const out = await mod.handler(event, {});
  if (!out) return res.status(200).json({ok:true});
  const headers = out.headers || {};
  Object.entries(headers).forEach(([k,v]) => res.setHeader(k, String(v)));
  let payload = out.body ?? '';
  if (out.isBase64Encoded) payload = Buffer.from(payload, 'base64');
  const status = Number(out.statusCode || 200);
  if (Buffer.isBuffer(payload)) return res.status(status).send(payload);
  res.status(status).send(payload);
};
