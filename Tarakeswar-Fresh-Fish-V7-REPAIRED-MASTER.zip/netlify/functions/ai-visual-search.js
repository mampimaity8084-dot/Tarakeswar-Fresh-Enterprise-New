
const {json}=require('./lib/supabase');
function parseJSON(t){try{return JSON.parse(t)}catch{}const m=String(t).match(/\{[\s\S]*\}/);if(m)try{return JSON.parse(m[0])}catch{}return null}
function outText(d){if(typeof d?.output_text==='string')return d.output_text;let t='';for(const i of (d?.output||[]))for(const c of (i?.content||[]))if(c?.type==='output_text')t+=c.text||'';return t}
function dataParts(s){const m=String(s||'').match(/^data:([^;]+);base64,(.+)$/);if(!m)throw Error('Invalid image');return {mime:m[1],base64:m[2],size:Buffer.byteLength(m[2],'base64')}}
exports.handler=async(event)=>{
 if(event.httpMethod!=='POST')return json(405,{error:'POST required'});
 try{
  const b=JSON.parse(event.body||'{}');const image=String(b.image_data_url||'');const d=dataParts(image);
  if(d.size>7*1024*1024)return json(400,{error:'Image too large'});
  const products=Array.isArray(b.products)?b.products.slice(0,120):[];
  if(!products.length)return json(200,{ok:true,matches:[]});
  const key=process.env.OPENAI_API_KEY;if(!key)return json(503,{error:'AI is not configured'});
  const model=process.env.OPENAI_MODEL||'gpt-5-mini';
  const catalog=products.map(p=>({id:p.id,name:p.name,category:p.category,unit:p.unit,available:p.available!==false,description:p.description||''}));
  const prompt=`Identify which products in this catalog are visually plausible matches to the uploaded food/fish photo. Return ONLY JSON {"matches":[{"id":"exact catalog id","confidence":0.0}]}. Never invent IDs. Do not infer price or stock. Catalog: ${JSON.stringify(catalog)}`;
  const input=[{role:'developer',content:'You are a visual product matcher. Use only exact catalog IDs supplied. Never invent commercial facts.'},{role:'user',content:[{type:'input_text',text:prompt},{type:'input_image',image_url:image,detail:'high'}]}];
  const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},body:JSON.stringify({model,input,text:{format:{type:'json_object'},verbosity:'low'},store:false})});
  const resp=await r.json().catch(()=>({}));if(!r.ok)return json(r.status,{error:resp?.error?.message||'AI provider error'});
  const obj=parseJSON(outText(resp))||{};const allowed=new Map(products.map(p=>[String(p.id),p]));
  const matches=(Array.isArray(obj.matches)?obj.matches:[]).filter(x=>allowed.has(String(x.id))).sort((a,b)=>Number(b.confidence||0)-Number(a.confidence||0)).slice(0,5).map(x=>({...allowed.get(String(x.id)),confidence:Number(x.confidence||0)}));
  return json(200,{ok:true,matches});
 }catch(e){return json(500,{error:e.message||String(e)})}
};
