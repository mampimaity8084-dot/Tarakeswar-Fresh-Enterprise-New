const {SUPABASE_URL,json,sb,getSecretKey}=require('./lib/supabase');
const keyId=()=>process.env.RAZORPAY_KEY_ID, keySecret=()=>process.env.RAZORPAY_KEY_SECRET;
exports.handler=async(event)=>{
 if(event.httpMethod!=='POST') return json(405,{error:'Method not allowed'});
 try{
  if(!keyId()||!keySecret()) return json(500,{error:'Razorpay server keys missing in Netlify'});
  if(!getSecretKey()) return json(500,{error:'Supabase server secret missing in Netlify'});
  const b=JSON.parse(event.body||'{}');
  const name=String(b.name||'').trim(), mobile=String(b.mobile||'').replace(/\D/g,'').replace(/^91(?=\d{10}$)/,''), area=String(b.area||'').trim();
  const method=b.payment_method==='ONLINE_FULL'?'ONLINE_FULL':'COD_ADVANCE'; const items=Array.isArray(b.items)?b.items:[];
  if(!name||mobile.length!==10||!area||!items.length) return json(400,{error:'Name, 10-digit mobile, area and cart are required'});
  const qtyMap=new Map(); for(const x of items){const id=String(x.product_id||'');const q=Math.max(1,Math.min(20,Math.floor(Number(x.qty)||1)));if(id)qtyMap.set(id,(qtyMap.get(id)||0)+q)}
  const ids=[...qtyMap.keys()]; if(!ids.length)return json(400,{error:'Invalid cart'});
  const products=await sb(`fish?select=id,name,price,unit,available,category&available=eq.true&id=in.(${ids.map(encodeURIComponent).join(',')})`);
  if(!Array.isArray(products)||products.length!==ids.length)return json(409,{error:'One or more products are unavailable. Refresh cart and try again.'});
  let total=0;const secureItems=products.map(p=>{const qty=qtyMap.get(String(p.id))||1,price=Number(p.price||0);total+=price*qty;return {product_id:String(p.id),name:p.name,qty,unit:p.unit||'',unit_price:price,line_total:price*qty,prep:String(items.find(x=>String(x.product_id)===String(p.id))?.prep||'').slice(0,80)}});
  const settingsRows=await sb('public_settings?select=cod_advance_percent,online_discount_percent,min_order,morning_slot_capacity,evening_slot_capacity&id=eq.1');const s=settingsRows?.[0]||{};
  const minOrder=Math.max(499,Number(s.min_order??499));if(total<minOrder)return json(409,{error:`Minimum order ₹${minOrder}. Add ₹${(minOrder-total).toFixed(0)} more product(s) to continue.`});const advPct=Math.max(0,Math.min(100,Number(s.cod_advance_percent??20))),discPct=Math.max(0,Math.min(30,Number(s.online_discount_percent??2)));
  const discount=method==='ONLINE_FULL'?Math.round(total*discPct)/100:0,payable=Math.max(0,total-discount),advance=method==='COD_ADVANCE'?Math.round(total*advPct)/100:payable,payNow=method==='COD_ADVANCE'?advance:payable,amount=Math.max(100,Math.round(payNow*100));
  const deliveryDate=String(b.delivery_date||'').slice(0,10),deliverySlot=String(b.delivery_slot||'').slice(0,60);if(!/^\d{4}-\d{2}-\d{2}$/.test(deliveryDate))return json(400,{error:'Invalid delivery date'});
  const cap=deliverySlot.toLowerCase().includes('evening')?Number(s.evening_slot_capacity||30):Number(s.morning_slot_capacity||30);
  const cnt=await sb(`orders?select=id&delivery_date=eq.${encodeURIComponent(deliveryDate)}&delivery_slot=eq.${encodeURIComponent(deliverySlot)}&status=neq.Cancelled`);if(Array.isArray(cnt)&&cnt.length>=cap)return json(409,{error:'Selected delivery slot is full. Please choose another slot.'});
  const auth=Buffer.from(`${keyId()}:${keySecret()}`).toString('base64');
  const rr=await fetch('https://api.razorpay.com/v1/orders',{method:'POST',headers:{Authorization:`Basic ${auth}`,'Content-Type':'application/json'},body:JSON.stringify({amount,currency:'INR',receipt:`TFF-${Date.now()}`,notes:{mobile,method,delivery_date:deliveryDate,delivery_slot:deliverySlot}})});
  const ro=await rr.json();if(!rr.ok)return json(rr.status===401?401:500,{error:ro?.error?.description||'Razorpay order creation failed'});
  const sess={razorpay_order_id:ro.id,guest_id:String(b.guest_id||'').slice(0,100)||null,customer_name:name,mobile,area,referral_code:String(b.referral_code||'').trim().toUpperCase().slice(0,30)||null,items:secureItems,total,delivery_date:deliveryDate,delivery_slot:deliverySlot,payment_method:method,advance_percent:method==='COD_ADVANCE'?advPct:100,advance_amount:advance,discount_amount:discount,payable_total:payable,pay_now:payNow,customer_note:String(b.customer_note||'').trim().slice(0,500)||null,status:'created'};
  let saved;
  for(let i=0;i<2;i++){try{saved=await sb('payment_sessions',{method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify(sess)});break}catch(e){if(i===1)throw e;await new Promise(r=>setTimeout(r,250))}}
  const sessionId=saved?.[0]?.id;if(!sessionId)throw new Error('Payment session was not created. Razorpay window was NOT opened.');
  console.log('checkout_session_created',JSON.stringify({session_id:sessionId,razorpay_order_id:ro.id,amount}));
  return json(200,{session_id:sessionId,order_id:ro.id,amount:ro.amount,currency:ro.currency,key_id:keyId(),total,pay_now:payNow,payable_total:payable,discount_amount:discount,advance_amount:advance});
 }catch(e){console.error('create-checkout',e);return json(500,{error:e.message||'Server error',code:'CHECKOUT_CREATE_FAILED'})}
};
