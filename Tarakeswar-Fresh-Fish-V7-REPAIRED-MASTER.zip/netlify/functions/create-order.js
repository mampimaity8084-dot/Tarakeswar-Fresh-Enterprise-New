exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  try {
    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keyId || !keySecret) return { statusCode: 500, body: JSON.stringify({ error: 'Razorpay environment variables are missing' }) };

    const body = JSON.parse(event.body || '{}');
    const amount = Math.round(Number(body.amount));
    const currency = body.currency || 'INR';
    const receipt = String(body.receipt || `tff_${Date.now()}`).slice(0, 40);
    if (!Number.isFinite(amount) || amount < 100) return { statusCode: 400, body: JSON.stringify({ error: 'Minimum payment amount is ₹1' }) };

    const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
    const r = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { 'Authorization': `Basic ${auth}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount, currency, receipt })
    });
    const data = await r.json();
    if (!r.ok) {
      const statusCode = r.status === 401 ? 401 : 500;
      return { statusCode, body: JSON.stringify({ error: data?.error?.description || 'Razorpay order creation failed' }) };
    }
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
      body: JSON.stringify({ order_id: data.id, amount: data.amount, currency: data.currency, key_id: keyId })
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message || 'Server error' }) };
  }
};
