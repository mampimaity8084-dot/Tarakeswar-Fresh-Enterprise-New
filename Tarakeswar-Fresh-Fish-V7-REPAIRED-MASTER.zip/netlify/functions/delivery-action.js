const {json,sb,SUPABASE_URL}=require('./lib/supabase');
const SERVICE_KEY=process.env.SUPABASE_SERVICE_ROLE_KEY||process.env.SUPABASE_SECRET_KEY||'';
async function api(path,method='GET',body,token){const auth=token||SERVICE_KEY;const r=await fetch(`${SUPABASE_URL}${path}`,{method,headers:{apikey:SERVICE_KEY,Authorization:`Bearer ${auth}`,'Content-Type':'application/json',Prefer:'return=representation'},body:body?JSON.stringify(body):undefined});const t=await r.text();let d;try{d=JSON.parse(t)}catch{d={raw:t}}if(!r.ok)throw new Error(d?.message||d?.msg||d?.error_description||d?.error||t||`HTTP ${r.status}`);return d}
async function currentUser(event){const a=event.headers?.authorization||event.headers?.Authorization||'';if(!a.startsWith('Bearer '))throw new Error('Delivery login required');return api('/auth/v1/user','GET',null,a.slice(7));}
async function partnerFor(u){const rows=await sb(`delivery_partner_profiles?user_id=eq.${encodeURIComponent(u.id)}&select=*`);const p=rows?.[0];if(!p)throw new Error('Delivery Partner profile পাওয়া যায়নি');if(p.active===false)throw new Error('Delivery Partner account inactive');return p;}
exports.handler=async(event)=>{if(event.httpMethod!=='POST')return json(405,{error:'POST required'});try{if(!SERVICE_KEY||!SUPABASE_URL)return json(500,{error:'Supabase server configuration missing'});const u=await currentUser(event);const p=await partnerFor(u);const b=JSON.parse(event.body||'{}');const action=String(b.action||'').trim();
 if(action==='profile'){
  const orders=await sb(`orders?delivery_partner_id=eq.${encodeURIComponent(p.id)}&select=*,customers(name,mobile,area,lat,lng),order_items(*)&order=delivery_date.asc`);
  const active=orders.filter(o=>['Packed','Out for Delivery'].includes(o.status));
  const delivered=orders.filter(o=>o.status==='Delivered');
  return json(200,{ok:true,profile:p,orders:active,delivered_count:delivered.length});
 }
 const orderId=String(b.order_id||'').trim();
 if(!orderId)return json(400,{error:'order_id required'});
 const own=await sb(`orders?id=eq.${encodeURIComponent(orderId)}&delivery_partner_id=eq.${encodeURIComponent(p.id)}&select=id,status,delivery_partner_id`);if(!own?.[0])return json(404,{error:'Order not assigned to this partner'});
 if(action==='status'){
  const status=String(b.status||'').trim();
  if(!['Out for Delivery'].includes(status))return json(400,{error:'Invalid delivery status'});
  const updated=await sb(`orders?id=eq.${encodeURIComponent(orderId)}&delivery_partner_id=eq.${encodeURIComponent(p.id)}`,{method:'PATCH',body:JSON.stringify({status})});
  return json(200,{ok:true,order:updated?.[0]||null});
 }
 if(action==='gps'){
  if(['Delivered','Cancelled'].includes(own[0].status))return json(409,{error:'Tracking is closed for this order'});
  const lat=Number(b.lat),lng=Number(b.lng),accuracy=b.accuracy==null?null:Number(b.accuracy),heading=b.heading==null?null:Number(b.heading),speed=b.speed==null?null:Number(b.speed);
  if(!Number.isFinite(lat)||!Number.isFinite(lng)||lat<-90||lat>90||lng<-180||lng>180)return json(400,{error:'Invalid GPS coordinates'});
  await sb(`orders?id=eq.${encodeURIComponent(orderId)}&delivery_partner_id=eq.${encodeURIComponent(p.id)}`,{method:'PATCH',body:JSON.stringify({delivery_lat:lat,delivery_lng:lng,location_updated_at:new Date().toISOString(),status:'Out for Delivery'})});
  await sb('delivery_locations',{method:'POST',body:JSON.stringify({order_id:orderId,rider_id:p.user_id,lat,lng,accuracy,heading,speed})});
  return json(200,{ok:true,lat,lng,updated_at:new Date().toISOString()});
 }
 if(action==='verify_otp'){
  const otp=String(b.otp||'').trim();if(!/^\d{4}$/.test(otp))return json(400,{error:'4-digit OTP required'});
  const result=await api('/rest/v1/rpc/verify_delivery_otp_v3','POST',{p_order_id:orderId,p_otp:otp});
  if(!result)return json(400,{ok:false,error:'OTP ভুল বা expired'});
  return json(200,{ok:true,verified:true,result});
 }
 return json(400,{error:'Unknown action'});
}catch(e){console.error('delivery-action',e);return json(403,{error:e.message||String(e)})}};
