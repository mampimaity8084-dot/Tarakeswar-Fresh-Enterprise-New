const crypto=require('crypto');
const {SUPABASE_URL,json,sb}=require('./lib/supabase');
const SERVICE_KEY=process.env.SUPABASE_SERVICE_ROLE_KEY||process.env.SUPABASE_SECRET_KEY||'';

function authHeaders(token){return {apikey:SERVICE_KEY,Authorization:`Bearer ${token}`,'Content-Type':'application/json'};}
async function api(path,method='GET',body,token=SERVICE_KEY){
  const r=await fetch(`${SUPABASE_URL}${path}`,{method,headers:authHeaders(token),body:body?JSON.stringify(body):undefined});
  const text=await r.text(); let data; try{data=JSON.parse(text)}catch{data={raw:text}};
  if(!r.ok) throw new Error(data?.msg||data?.message||data?.error_description||data?.error||text||`HTTP ${r.status}`);
  return data;
}
async function currentUser(event){
  const h=event.headers||{}; const auth=h.authorization||h.Authorization||'';
  if(!auth.startsWith('Bearer ')) throw new Error('Admin login required');
  return api('/auth/v1/user','GET',null,auth.slice(7));
}
function isAdmin(u){
  const allow=(process.env.ADMIN_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
  const email=String(u?.email||'').toLowerCase();
  return (allow.length&&allow.includes(email)) || u?.app_metadata?.role==='admin' || u?.user_metadata?.role==='admin';
}
exports.handler=async(event)=>{
  if(event.httpMethod!=='POST') return json(405,{error:'Method not allowed'});
  try{
    if(!SERVICE_KEY||!SUPABASE_URL) return json(500,{error:'Supabase server configuration missing'});
    const u=await currentUser(event);
    if(!isAdmin(u)) return json(403,{error:'Admin permission required. Add your admin email to ADMIN_EMAILS in Netlify or set role=admin.'});
    const b=JSON.parse(event.body||'{}'); const action=String(b.action||'').trim();
    if(action==='create'){
      const email=String(b.email||'').trim().toLowerCase(),name=String(b.name||'').trim(),mobile=String(b.mobile||'').replace(/\D/g,'').slice(-10),vehicle=String(b.vehicle||'').trim();
      if(!email||!name) return json(400,{error:'Name and email are required'});
      let user=null;
      try{
        const password=crypto.randomBytes(18).toString('base64url')+'Aa1!';
        user=await api('/auth/v1/admin/users','POST',{email,password,email_confirm:true,user_metadata:{role:'delivery_partner',name}});
      }catch(e){
        if(!String(e.message).toLowerCase().includes('already')) throw e;
        const list=await api(`/auth/v1/admin/users?email=${encodeURIComponent(email)}`,'GET');
        user=(list?.users||list?.data||[])[0];
      }
      if(!user?.id) throw new Error('Could not create/find Auth user');
      const rows=await sb(`delivery_partner_profiles?user_id=eq.${encodeURIComponent(user.id)}`,{});
      const payload={user_id:user.id,name,mobile:mobile||null,vehicle:vehicle||null,active:true};
      if(Array.isArray(rows)&&rows.length) await sb(`delivery_partner_profiles?id=eq.${encodeURIComponent(rows[0].id)}`,{method:'PATCH',body:JSON.stringify(payload)});
      else await sb('delivery_partner_profiles',{method:'POST',body:JSON.stringify(payload)});
      return json(200,{ok:true,user_id:user.id,name,email});
    }
    if(action==='list'){
      const rows=await sb('delivery_partner_profiles?select=id,user_id,name,mobile,vehicle,active,total_earnings,base_pay,surge_multiplier,rain_surge,login_at,logout_at&order=name.asc');
      const users=await api('/auth/v1/admin/users?per_page=100','GET');
      const map={}; for(const u of (users?.users||[])) map[u.id]=u.email||'';
      return json(200,{ok:true,partners:(rows||[]).map(x=>({...x,email:map[x.user_id]||''}))});
    }
    if(action==='update'){
      const id=String(b.id||'').trim();
      if(!id) return json(400,{error:'Partner id required'});
      const payload={};
      if(b.base_pay!==undefined) payload.base_pay=Math.max(0,Number(b.base_pay)||0);
      if(b.surge_multiplier!==undefined) payload.surge_multiplier=Math.max(0.1,Number(b.surge_multiplier)||1);
      if(b.rain_surge!==undefined) payload.rain_surge=Math.max(0,Number(b.rain_surge)||0);
      if(b.active!==undefined) payload.active=Boolean(b.active);
      if(!Object.keys(payload).length) return json(400,{error:'No partner settings supplied'});
      await sb(`delivery_partner_profiles?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify(payload)});
      return json(200,{ok:true});
    }
    if(action==='service_get'){
      const rows=await sb('delivery_service_settings?id=eq.1&select=*');
      return json(200,{ok:true,settings:rows?.[0]||null});
    }
    if(action==='service_save'){
      const payload={
        service_name:String(b.service_name||'Tarakeswar Fresh Delivery').trim(),
        subtitle:String(b.subtitle||'').trim(),
        benefits:Array.isArray(b.benefits)?b.benefits.map(x=>String(x).trim()).filter(Boolean).slice(0,12):[],
        default_base_pay:Math.max(0,Number(b.default_base_pay)||0),
        default_surge_multiplier:Math.max(0.1,Number(b.default_surge_multiplier)||1),
        default_rain_surge:Math.max(0,Number(b.default_rain_surge)||0),
        free_delivery_min:Math.max(0,Number(b.free_delivery_min)||0),
        delivery_note:String(b.delivery_note||'').trim(),
        active:b.active!==false,
        updated_at:new Date().toISOString()
      };
      await sb('delivery_service_settings?id=eq.1',{method:'PATCH',body:JSON.stringify(payload)});
      return json(200,{ok:true,settings:payload});
    }
    if(action==='magiclink'){
      const email=String(b.email||'').trim().toLowerCase();
      if(!email) return json(400,{error:'Partner email required'});
      const host=String(event.headers?.host||'').split(',')[0].trim();
      const proto=(event.headers?.['x-forwarded-proto']||'https').split(',')[0];
      const redirectTo=`${proto}://${host}/delivery.html`;
      const link=await api('/auth/v1/admin/generate_link','POST',{type:'magiclink',email,redirect_to:redirectTo});
      if(!link?.action_link) return json(500,{error:'Magic login link was not returned by Supabase'});
      return json(200,{ok:true,action_link:link.action_link,redirect_to:redirectTo,expires_in:3600});
    }
    return json(400,{error:'Unknown action'});
  }catch(e){return json(500,{error:e.message||String(e)})}
};
