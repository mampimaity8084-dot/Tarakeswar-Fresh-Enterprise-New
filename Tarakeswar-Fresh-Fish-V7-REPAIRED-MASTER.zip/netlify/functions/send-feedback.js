const {supabaseFetch}=require('./lib/supabase');
function normalizePhone(v){let d=String(v||'').replace(/\D/g,'');if(d.length===10)d='91'+d;return d}
async function mark(orderId,status,error){try{await supabaseFetch(`/rest/v1/orders?id=eq.${encodeURIComponent(orderId)}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({feedback_status:status,feedback_error:error||null})})}catch(e){console.warn('feedback status update failed',e.message)}}
exports.handler=async(event)=>{
 const headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization,content-type','Content-Type':'application/json','Cache-Control':'no-store'};
 if(event.httpMethod==='OPTIONS') return {statusCode:204,headers,body:''};
 let orderId='';
 try{
  const auth=event.headers?.authorization||event.headers?.Authorization||'';
  const token=auth.replace(/^Bearer\s+/i,'');
  orderId=JSON.parse(event.body||'{}').order_id;
  if(!token) throw new Error('Admin authentication required');
  if(!orderId) throw new Error('order_id required');
  const user=await supabaseFetch('/auth/v1/user',{headers:{Authorization:`Bearer ${token}`} });
  if(!user?.id) throw new Error('Admin authentication required');
  const rows=await supabaseFetch(`/rest/v1/orders?select=id,order_no,status,customers(name,mobile)&id=eq.${encodeURIComponent(orderId)}&limit=1`);
  const order=rows?.[0];if(!order)throw new Error('Order not found');
  if(order.status!=='Delivered')throw new Error('Order must be Delivered first');
  const phoneId=process.env.WHATSAPP_PHONE_NUMBER_ID,accessToken=process.env.WHATSAPP_ACCESS_TOKEN,version=process.env.WHATSAPP_GRAPH_VERSION,feedbackUrl=process.env.FEEDBACK_FORM_URL;
  if(!phoneId||!accessToken||!version||!feedbackUrl)throw new Error('WhatsApp secrets incomplete — feedback will work after Meta credentials/template settings are added in Netlify.');
  const to=normalizePhone(order.customers?.mobile);if(!/^91\d{10}$/.test(to))throw new Error('Customer mobile is not a valid Indian 10-digit number');
  const name=order.customers?.name||'Customer';
  const template=process.env.WHATSAPP_TEMPLATE_NAME,lang=process.env.WHATSAPP_TEMPLATE_LANG||'bn';
  const payload=template?{messaging_product:'whatsapp',to,type:'template',template:{name:template,language:{code:lang},components:[{type:'body',parameters:[{type:'text',text:name},{type:'text',text:feedbackUrl}]}]}}:{messaging_product:'whatsapp',to,type:'text',text:{preview_url:true,body:`নমস্কার ${name} 🙏\nTarakeswar Fresh Fish থেকে অর্ডার করার জন্য ধন্যবাদ ❤️\n⭐ Feedback: ${feedbackUrl}`}};
  const r=await fetch(`https://graph.facebook.com/${version}/${phoneId}/messages`,{method:'POST',headers:{Authorization:`Bearer ${accessToken}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const body=await r.json();if(!r.ok)throw new Error('WhatsApp API error: '+JSON.stringify(body));
  await mark(orderId,'sent',null);
  return {statusCode:200,headers,body:JSON.stringify({ok:true,meta:body})};
 }catch(e){const msg=e.message||String(e);if(orderId)await mark(orderId,'failed',msg);return {statusCode:400,headers,body:JSON.stringify({ok:false,error:msg})}}
};
