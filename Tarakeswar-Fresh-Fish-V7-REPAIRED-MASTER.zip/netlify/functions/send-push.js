const {json,sb}=require('./lib/supabase');const {pushToAll}=require('./lib/push');
async function adminUser(event){
 const auth=event.headers?.authorization||event.headers?.Authorization||'';
 if(!auth.startsWith('Bearer '))throw new Error('Admin login required');
 const r=await fetch(`${process.env.SUPABASE_URL}/auth/v1/user`,{headers:{apikey:process.env.SUPABASE_SERVICE_ROLE_KEY||process.env.SUPABASE_SECRET_KEY,Authorization:auth}});
 const u=await r.json();if(!r.ok)throw new Error('Invalid admin session');
 const allow=(process.env.ADMIN_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
 if(!((allow.length&&allow.includes(String(u.email||'').toLowerCase()))||u.app_metadata?.role==='admin'||u.user_metadata?.role==='admin'))throw new Error('Admin permission required');
 return u;
}
exports.handler=async(event)=>{
 if(event.httpMethod!=='POST')return json(405,{error:'Method not allowed'});
 try{
  await adminUser(event);
  const b=JSON.parse(event.body||'{}');const title=String(b.title||'Tarakeswar Fresh Fish'),body=String(b.body||''),url=String(b.url||'/');
  if(!body)return json(400,{error:'Notification body required'});
  const r=await pushToAll({title,body,icon:'/logo-transparent.png',badge:'/logo-transparent.png',data:{url}},sb);
  return json(200,{ok:true,...r, message:r.enabled===false?'Push notification server keys are not configured yet. The app can still be deployed and tested.':''});
 }catch(e){return json(403,{error:e.message||String(e)})}
};
