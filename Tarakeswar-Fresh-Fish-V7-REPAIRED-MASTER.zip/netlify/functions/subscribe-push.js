const {json,sb}=require('./lib/supabase');
exports.handler=async(event)=>{
 if(event.httpMethod!=='POST')return json(405,{error:'Method not allowed'});
 try{
  const b=JSON.parse(event.body||'{}'),s=b.subscription||{};
  if(!s.endpoint||!s.keys?.p256dh||!s.keys?.auth)return json(400,{error:'Invalid subscription'});
  const payload={guest_id:String(b.guest_id||'').slice(0,120)||null,endpoint:s.endpoint,p256dh:s.keys.p256dh,auth:s.keys.auth,user_agent:event.headers?.['user-agent']||'',enabled:true,updated_at:new Date().toISOString()};
  const rows=await sb('push_subscriptions?on_conflict=endpoint',{method:'POST',body:JSON.stringify(payload),headers:{Prefer:'resolution=merge-duplicates'}});
  return json(200,{ok:true});
 }catch(e){return json(500,{error:e.message||String(e)})}
};
