const {json}=require('./lib/supabase');
exports.handler=async()=>json(200,{publicKey:process.env.VAPID_PUBLIC_KEY||'',enabled:!!process.env.VAPID_PUBLIC_KEY});
