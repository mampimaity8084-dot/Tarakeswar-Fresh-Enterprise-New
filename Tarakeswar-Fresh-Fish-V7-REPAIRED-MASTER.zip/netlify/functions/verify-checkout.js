const crypto=require('crypto');
const {json,sb,getSecretKey}=require('./lib/supabase');
async function razorpayGet(path,auth,opts={}){const r=await fetch(`https://api.razorpay.com/v1/${path}`,{...opts,headers:{Authorization:`Basic ${auth}`,'Content-Type':'application/json',...(opts.headers||{})}});const d=await r.json();return {r,d}}
exports.handler=async(event)=>{
 if(event.httpMethod!=='POST')return json(405,{error:'Method not allowed'});
 try{
  const secret=process.env.RAZORPAY_KEY_SECRET,keyId=process.env.RAZORPAY_KEY_ID;if(!secret||!keyId)return json(500,{error:'Razorpay server keys missing'});if(!getSecretKey())return json(500,{error:'Supabase server secret missing'});
  const b=JSON.parse(event.body||'{}'),{session_id,razorpay_order_id,razorpay_payment_id,razorpay_signature}=b;
  if(!razorpay_order_id||!razorpay_payment_id||!razorpay_signature)return json(400,{error:'Missing payment verification fields'});
  const expected=crypto.createHmac('sha256',secret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');const a=Buffer.from(expected),c=Buffer.from(String(razorpay_signature));
  if(a.length!==c.length||!crypto.timingSafeEqual(a,c))return json(400,{verified:false,error:'Payment signature verification failed'});
  const auth=Buffer.from(`${keyId}:${secret}`).toString('base64');const {r:pr,d:pay}=await razorpayGet(`payments/${encodeURIComponent(razorpay_payment_id)}`,auth);if(!pr.ok)return json(400,{error:pay?.error?.description||'Unable to validate Razorpay payment'});
  if(pay.order_id!==razorpay_order_id)return json(400,{error:'Razorpay order mismatch'});
  let sessions;
  if(session_id)sessions=await sb(`payment_sessions?select=*&id=eq.${encodeURIComponent(session_id)}&razorpay_order_id=eq.${encodeURIComponent(razorpay_order_id)}`);else sessions=await sb(`payment_sessions?select=*&razorpay_order_id=eq.${encodeURIComponent(razorpay_order_id)}`);
  const sess=sessions?.[0];if(!sess)return json(404,{verified:false,error:'Payment session not found for this Razorpay order. No order was created.'});
  if(Number(pay.amount)!==Math.round(Number(sess.pay_now)*100))return json(400,{error:'Payment amount/order mismatch'});
  if(pay.status==='authorized'){const {r:cr,d:cap}=await razorpayGet(`payments/${encodeURIComponent(razorpay_payment_id)}/capture`,auth,{method:'POST',body:JSON.stringify({amount:pay.amount,currency:'INR'})});if(!cr.ok)return json(400,{error:cap?.error?.description||'Payment capture failed'});}
  const status=pay.status==='authorized'?'captured':pay.status;if(status!=='captured')return json(400,{error:`Payment not captured (${status||'unknown'})`});
  const fin=await sb('rpc/finalize_payment_session_v3',{method:'POST',body:JSON.stringify({p_session_id:sess.id,p_payment_id:razorpay_payment_id})});const row=Array.isArray(fin)?fin[0]:fin;
  if(!row?.order_id)throw new Error('Payment verified but order finalization returned no order');
  console.log('payment_finalized',JSON.stringify({session_id:sess.id,razorpay_order_id,razorpay_payment_id,order_no:row.order_no}));
  return json(200,{verified:true,order_no:row.order_no,order_id:row.order_id,referral_code:row.customer_referral_code,delivery_otp:row.delivery_otp,payment_id:razorpay_payment_id});
 }catch(e){console.error('verify-payment',e);return json(500,{verified:false,error:e.message||'Server error',code:'PAYMENT_VERIFY_FAILED'})}
};
