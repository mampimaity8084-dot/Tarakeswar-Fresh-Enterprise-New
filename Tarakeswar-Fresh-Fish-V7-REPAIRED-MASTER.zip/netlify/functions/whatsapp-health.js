const {json}=require('./lib/supabase');
exports.handler=async()=>{
 const required=['WHATSAPP_PHONE_NUMBER_ID','WHATSAPP_ACCESS_TOKEN','WHATSAPP_GRAPH_VERSION','FEEDBACK_FORM_URL'];
 const missing=required.filter(k=>!process.env[k]);
 return json(200,{ok:missing.length===0,configured:missing.length===0,missing,template_configured:!!process.env.WHATSAPP_TEMPLATE_NAME,note:missing.length?'Add the missing Netlify environment variables, then redeploy.':'Credentials are present; send a real message only after Meta template/policy setup is verified.'});
};
