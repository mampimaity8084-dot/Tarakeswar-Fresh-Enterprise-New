TARAKESWAR FRESH FISH — MASTER V4.1 STORE-READY PACK
=====================================================

এই build Netlify/PWA deployment-এর জন্য প্রস্তুত এবং Android Play Store + Apple App Store packaging-এর জন্য প্রয়োজনীয় configuration/checklist যোগ করা হয়েছে।

গুরুত্বপূর্ণ:
- এই ZIP-এর ভিতরে WhatsApp access token বা VAPID private key নেই।
- Play Store-এর AAB এবং Apple-এর IPA signing certificate/account থেকে তৈরি করতে হবে; এগুলো ZIP-এর মধ্যে hard-code করা হয়নি।
- আগে Netlify-তে production URL চালু করুন। তারপর store/native-config.js-এ সেই URL বসিয়ে native packaging করুন।

৩টি আলাদা app identity:
1) Customer: com.tarakeswarfreshfish.customer
2) Delivery: com.tarakeswarfreshfish.delivery
3) Admin: com.tarakeswarfreshfish.admin

প্রস্তাবিত প্রথম store release: Customer App.
Delivery/Admin-এর জন্য PWA install/QR রাখা হয়েছে; চাইলে পরে আলাদা store listing করা যাবে।
