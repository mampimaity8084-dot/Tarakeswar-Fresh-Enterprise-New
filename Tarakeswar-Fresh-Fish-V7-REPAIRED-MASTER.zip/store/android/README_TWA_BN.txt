ANDROID PLAY STORE — TWA PATH
=============================

Recommended for the Customer PWA if you want the web/PWA deployment to remain the source of truth.

1. Deploy the project to Netlify and confirm HTTPS + manifest + service worker work.
2. Install Node.js + Java JDK + Android Studio.
3. Install Bubblewrap:
   npm i -g @bubblewrap/cli
4. Run:
   bubblewrap init --manifest https://YOUR-SITE.netlify.app/manifest.webmanifest
5. Set package name:
   com.tarakeswarfreshfish.customer
6. Build the signed Android App Bundle (.aab):
   bubblewrap build
7. Create/keep the signing keystore safe. NEVER commit it to this ZIP/repository.
8. Add Digital Asset Links at:
   https://YOUR-SITE.netlify.app/.well-known/assetlinks.json
   using the SHA-256 certificate fingerprint of the signing key.
9. Test the release build on a real Android phone.
10. Google Play Console → Create app → upload AAB → store listing → content/app declarations → testing → production release.

Do not publish until the production URL, login, payment, checkout, GPS and app links are tested.
