APPLE APP STORE — CAPACITOR PATH
================================

Apple review requires a real, functional iOS app; a thin website wrapper can be rejected under the Minimum Functionality guideline. This project therefore needs a proper Capacitor/Xcode packaging layer and real on-device testing.

1. Deploy Netlify first and set the final HTTPS URL.
2. Install Node.js + Xcode on a Mac.
3. In a packaging copy of the project:
   npm install @capacitor/core @capacitor/cli @capacitor/ios
   npx cap init "Tarakeswar Fresh Fish" "com.tarakeswarfreshfish.customer"
   npx cap add ios
4. Configure the production API base using store/native-config.example.js.
5. Open the iOS project:
   npx cap open ios
6. Configure signing/team, app icon, camera/photo/GPS usage descriptions and notification capabilities in Xcode.
7. Test on a real iPhone.
8. Apple Developer → App Store Connect → New App → iOS → bundle ID.
9. Upload the build with Xcode/Transporter.
10. TestFlight → internal/external testing → App Review → Submit for Review.

Keep demo account/reviewer instructions ready because the app has account-based features and backend services.
