import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
function normalizePhone(v:string){let d=(v||"").replace(/\D/g,"");if(d.length===10)d="91"+d;return d}
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 try{
  const supabaseUrl=Deno.env.get("SUPABASE_URL")!;
  const serviceRole=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const admin=createClient(supabaseUrl,serviceRole);
  const auth=req.headers.get("Authorization")||"";const token=auth.replace(/^Bearer\s+/i,"");
  const {data:{user},error:userErr}=await admin.auth.getUser(token);if(userErr||!user)throw new Error("Admin authentication required");
  const {order_id}=await req.json();if(!order_id)throw new Error("order_id required");
  const {data:order,error}=await admin.from("orders").select("id,order_no,status,feedback_sent_at,customers(name,mobile)").eq("id",order_id).single();if(error)throw error;
  if(order.status!=="Delivered")throw new Error("Order must be Delivered first");
  const phoneId=Deno.env.get("WHATSAPP_PHONE_NUMBER_ID");const accessToken=Deno.env.get("WHATSAPP_ACCESS_TOKEN");const version=Deno.env.get("WHATSAPP_GRAPH_VERSION");const feedbackUrl=Deno.env.get("FEEDBACK_FORM_URL");
  if(!phoneId||!accessToken||!version||!feedbackUrl)throw new Error("WhatsApp secrets incomplete: WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_ACCESS_TOKEN, WHATSAPP_GRAPH_VERSION, FEEDBACK_FORM_URL");
  const to=normalizePhone(order.customers.mobile);const name=order.customers.name||"Customer";const template=Deno.env.get("WHATSAPP_TEMPLATE_NAME");const lang=Deno.env.get("WHATSAPP_TEMPLATE_LANG")||"bn";
  let payload:any;
  if(template){payload={messaging_product:"whatsapp",to,type:"template",template:{name:template,language:{code:lang},components:[{type:"body",parameters:[{type:"text",text:name},{type:"text",text:feedbackUrl}]}]}}}
  else {payload={messaging_product:"whatsapp",recipient_type:"individual",to,type:"text",text:{preview_url:true,body:`নমস্কার ${name} 🙏\nTarakeswar Fresh Fish থেকে অর্ডার করার জন্য ধন্যবাদ ❤️\nআপনার মতামত আমাদের পরিষেবা আরও ভালো করতে সাহায্য করবে।\n⭐ Feedback দিন: ${feedbackUrl}`}}}
  const res=await fetch(`https://graph.facebook.com/${version}/${phoneId}/messages`,{method:"POST",headers:{"Authorization":`Bearer ${accessToken}`,"Content-Type":"application/json"},body:JSON.stringify(payload)});const body=await res.json();
  if(!res.ok){await admin.from("orders").update({feedback_status:"failed",feedback_error:JSON.stringify(body)}).eq("id",order_id);throw new Error("WhatsApp API error: "+JSON.stringify(body))}
  await admin.from("orders").update({feedback_sent_at:new Date().toISOString(),feedback_status:"sent",feedback_error:null}).eq("id",order_id);
  return new Response(JSON.stringify({ok:true,meta:body}),{headers:{...corsHeaders,"Content-Type":"application/json"}})
 }catch(e){return new Response(JSON.stringify({ok:false,error:e?.message||String(e)}),{status:400,headers:{...corsHeaders,"Content-Type":"application/json"}})}
});
