-- V4.3 development proposal only. NEVER run against production without approval.
-- Additive and idempotent; intentionally contains no destructive operations.

create extension if not exists pgcrypto;

alter table if exists public.orders
  add column if not exists delivery_otp_issued_at timestamptz,
  add column if not exists delivery_otp_expires_at timestamptz,
  add column if not exists delivery_otp_attempts integer not null default 0;

create table if not exists public.order_otp_v43 (
  order_id uuid primary key references public.orders(id) on delete cascade,
  otp_ciphertext text not null,
  expires_at timestamptz not null,
  attempts integer not null default 0,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.order_otp_v43 enable row level security;
revoke all on public.order_otp_v43 from anon, authenticated;

create index if not exists idx_order_otp_v43_expiry
  on public.order_otp_v43(expires_at);

create table if not exists public.payment_idempotency_v43 (
  idempotency_key text primary key,
  session_id uuid,
  razorpay_order_id text,
  finalized_order_id uuid,
  status text not null default 'started',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.payment_idempotency_v43 enable row level security;
revoke all on public.payment_idempotency_v43 from anon, authenticated;

create index if not exists idx_payment_idempotency_v43_session
  on public.payment_idempotency_v43(session_id);