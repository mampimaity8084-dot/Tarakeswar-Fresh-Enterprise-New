-- TARAKESWAR FRESH FISH V5.2
-- Partner & Family Hub
-- Run once in Supabase SQL Editor.

create table if not exists public.partner_family_hub(
 id uuid primary key default gen_random_uuid(),
 type text not null default 'restaurant' check(type in ('restaurant','event','family')),
 title text not null,
 subtitle text,
 description text,
 image_url text,
 action_label text default 'Open',
 action_url text,
 sort_order integer not null default 10,
 active boolean not null default true,
 customer_customizable boolean not null default true,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

alter table public.partner_family_hub enable row level security;

drop policy if exists "public read active partner family hub" on public.partner_family_hub;
create policy "public read active partner family hub"
on public.partner_family_hub for select
to anon, authenticated
using (active=true);

drop policy if exists "authenticated manage partner family hub" on public.partner_family_hub;
create policy "authenticated manage partner family hub"
on public.partner_family_hub for all
to authenticated
using (true) with check (true);

create index if not exists idx_partner_family_hub_active_sort
on public.partner_family_hub(active, sort_order);

-- Seed examples. Replace/delete these from Admin > Partner & Family.
insert into public.partner_family_hub(type,title,subtitle,description,image_url,action_label,sort_order,active,customer_customizable)
select 'restaurant','Partner Restaurant','Special Partner Offer','Partner restaurant-এর menu, combo ও offer এখানে দেখুন।','/logo-transparent.png','Offer দেখুন',10,true,true
where not exists (select 1 from public.partner_family_hub where title='Partner Restaurant');

insert into public.partner_family_hub(type,title,subtitle,description,image_url,action_label,sort_order,active,customer_customizable)
select 'event','Event & Catering Partner','Party • অনুষ্ঠান • Catering','Birthday, Puja, Anniversary বা Event-এর জন্য partner service ও combo request করুন।','/logo-transparent.png','Request করুন',20,true,true
where not exists (select 1 from public.partner_family_hub where title='Event & Catering Partner');

insert into public.partner_family_hub(type,title,subtitle,description,image_url,action_label,sort_order,active,customer_customizable)
select 'family','Family Hub','পরিবারের জন্য আলাদা তালিকা','পরিবারের পছন্দ, quantity note ও special instruction নিজের মতো সাজিয়ে রাখুন।','/logo-transparent.png','Customize',30,true,true
where not exists (select 1 from public.partner_family_hub where title='Family Hub');

-- Optional storage bucket for partner/event images.
insert into storage.buckets(id,name,public)
values('partner-family','partner-family',true)
on conflict(id) do update set public=true;

drop policy if exists "public read partner family images" on storage.objects;
create policy "public read partner family images"
on storage.objects for select
to anon, authenticated
using (bucket_id='partner-family');
