-- V5.2 Ultimate support/review foundation
create table if not exists public.support_tickets (
 id uuid primary key default gen_random_uuid(),
 customer_id uuid null,
 category text not null default 'Other',
 message text not null,
 status text not null default 'pending',
 admin_reply text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.customer_reviews (
 id uuid primary key default gen_random_uuid(),
 customer_id uuid null,
 rating integer not null check (rating between 1 and 5),
 review text,
 created_at timestamptz not null default now()
);
alter table public.support_tickets enable row level security;
alter table public.customer_reviews enable row level security;
drop policy if exists "support_tickets_insert_public" on public.support_tickets;
create policy "support_tickets_insert_public" on public.support_tickets for insert to anon,authenticated with check (true);
drop policy if exists "reviews_insert_public" on public.customer_reviews;
create policy "reviews_insert_public" on public.customer_reviews for insert to anon,authenticated with check (rating between 1 and 5);
-- Admin/service-role reads remain available through the existing server-side service role functions.
