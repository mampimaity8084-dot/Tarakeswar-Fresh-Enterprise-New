import fs from 'fs'; import assert from 'assert';
const root=new URL('..',import.meta.url).pathname;
for(const f of ['index.html','admin.html','delivery.html','tff-v6-runtime.js','tff-v6-final.js']) assert.ok(fs.existsSync(`${root}/${f}`),`${f} missing`);
for(const f of ['index.html','admin.html','delivery.html']){const s=fs.readFileSync(`${root}/${f}`,'utf8'); assert.ok(s.includes('/tff-v6-runtime.js'),`${f}: runtime missing`); assert.ok(!s.includes('/master-v4.js'),`${f}: old runtime still wired`);}
console.log('V6 static checks passed');
