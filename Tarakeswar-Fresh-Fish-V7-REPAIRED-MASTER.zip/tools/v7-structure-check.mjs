import fs from 'fs';
const required=['index.html','admin.html','delivery.html','privacy.html','package.json','vercel.json','netlify/functions'];
for (const p of required) if (!fs.existsSync(p)) { console.error('MISSING:',p); process.exitCode=1; }
if (!process.exitCode) console.log('V7 structure OK');
